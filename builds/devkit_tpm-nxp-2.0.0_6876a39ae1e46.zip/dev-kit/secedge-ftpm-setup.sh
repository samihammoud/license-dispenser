#!/bin/sh
# This expects the name of the build directory as the only argument.

if [ $# != 1 -o ! -d $1 ]; then
  echo "Usage: $0 <build-dir>"
  exit
fi

LOCAL_CONF=${1}/conf/local.conf
if [ ! -f ${LOCAL_CONF}.imx ]; then
  cp -a $LOCAL_CONF ${LOCAL_CONF}.imx
else
  # Reset to the original file before modifying
  cp -a ${LOCAL_CONF}.imx $LOCAL_CONF
fi

BBLAYERS_CONF=${1}/conf/bblayers.conf
if [ ! -f ${BBLAYERS_CONF}.imx ]; then
  cp -a $BBLAYERS_CONF ${BBLAYERS_CONF}.imx
else
  # Reset to the original file before modifying
  cp -a ${BBLAYERS_CONF}.imx $BBLAYERS_CONF
fi

echo '' >> $LOCAL_CONF
echo '# The following adds the fTPM helper app and startup scripts' >> $LOCAL_CONF
echo 'DISTRO_FEATURES:append = " systemd usrmerge"' >> $LOCAL_CONF
echo 'DISTRO_FEATURES_BACKFILL_CONSIDERED += "sysvinit"' >> $LOCAL_CONF
echo 'VIRTUAL-RUNTIME_init_manager = "systemd"' >> $LOCAL_CONF
echo 'VIRTUAL-RUNTIME_initscripts = "systemd-compat-units"' >> $LOCAL_CONF
echo '' >> $LOCAL_CONF
echo 'IMAGE_INSTALL:append = " git"' >> $LOCAL_CONF
echo 'IMAGE_INSTALL:append = " python3"' >> $LOCAL_CONF
echo 'IMAGE_INSTALL:append = " python3-pip"' >> $LOCAL_CONF
echo 'IMAGE_INSTALL:append = " activation-init"' >> $LOCAL_CONF
echo 'IMAGE_INSTALL:append = " activation-app"' >> $LOCAL_CONF
echo '' >> $LOCAL_CONF
echo '# Uncomment the following to add the tpm2 utilities if required' >> $LOCAL_CONF
echo '#MACHINE_FEATURES:append = " tpm2"' >> $LOCAL_CONF
echo '#IMAGE_INSTALL:append = " packagegroup-security-tpm2"' >> $LOCAL_CONF

echo 'BBLAYERS += "${BSPDIR}/sources/meta-seftpm-optee"' >> $BBLAYERS_CONF

FTPM_PACKAGE=`pwd`
SOURCE_DIR=${1}/../sources
cd ${SOURCE_DIR}
tar xvf ${FTPM_PACKAGE}/meta-seftpm-optee.tar.gz
